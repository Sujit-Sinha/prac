from multiprocessing import Queue, Process
import time


def write_to(container, arr):
    for data in arr:
      container.put(data)
def read_from(container):
    time.sleep(0.1)
    while not container.empty():
       print('Printing from P2 {}'.format(container.get()))


def write_read(container, arr):
    for data in arr:
      container.put(data)
    print('[=] Reading in write task & first data is {}'.format(container.get()))
def read_write(container):
    time.sleep(0.1)
    while not container.empty():
        print('Printing from P4 {}'.format(container.get()))
    container.put('read_write')
    print('[=] Writing in read task & the data is <{}>'.format(container.get()))


if __name__=='__main__':
   # Create Queue object
   Q=Queue()
   # Create Process class objects
   val_list=[1,2,3,4,5,6,7,8,9]
   P1=Process(target=write_to, args=(Q,val_list,))
   P2=Process(target=read_from, args=(Q,))
   # Bothway data flow test:
   P3=Process(target=write_read, args=(Q,val_list,))
   P4=Process(target=read_write, args=(Q,))
   # Start Process
   P1.start()
   P2.start()

   # Hold until both are terminated
   P1.join()
   P2.join()
   P3.start()
   P4.start()
   P3.join()
   P4.join()
   print('==========ONE WAY DATA FLOW TESTED==========')